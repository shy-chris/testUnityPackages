/*
 * @author:		CT
 * @date:		22/05/2017 09:38
 * @project:	Essentials
 * @company:	b.ReX
 */

using UnityEngine;

/// <summary>
/// GameobjectExtention
/// some extentions for Vector
/// </summary>
public static class VectorExtention
{
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector3 vec, float min, float max, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= max && vec.x >= min &&
			        vec.y <= max && vec.y >= min &&
			        vec.z <= max && vec.z >= min);
		}
		else
		{
			return (vec.x < max && vec.x > min &&
			        vec.y < max && vec.y > min &&
			        vec.z < max && vec.z > min);
		}
	}
	
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector2 vec, float min, float max, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= max && vec.x >= min &&
			        vec.y <= max && vec.y >= min);
		}
		else
		{
			return (vec.x < max && vec.x > min &&
			        vec.y < max && vec.y > min);
		}
	}
	
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector3 vec, float threshold, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= threshold && vec.x >= -threshold &&
			        vec.y <= threshold && vec.y >= -threshold &&
			        vec.z <= threshold && vec.z >= -threshold);
		}
		else
		{
			return (vec.x < threshold && vec.x > -threshold &&
			        vec.y < threshold && vec.y > -threshold &&
			        vec.z < threshold && vec.z > -threshold);
		}
	}
	
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector2 vec, float threshold, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= threshold && vec.x >= -threshold &&
			        vec.y <= threshold && vec.y >= -threshold);
		}
		else
		{
			return (vec.x < threshold && vec.x > -threshold &&
			        vec.y < threshold && vec.y > -threshold);
		}
	}
	
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector3 vec, Vector3 min, Vector3 max, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= max.x && vec.x >= min.x &&
			        vec.y <= max.y && vec.y >= min.y &&
			        vec.z <= max.z && vec.z >= min.z);
		}
		else
		{
			return (vec.x < max.x && vec.x > min.x &&
			        vec.y < max.y && vec.y > min.y &&
			        vec.z < max.z && vec.z > min.z);
		}
	}
	
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector2 vec, Vector3 min, Vector3 max, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= max.x && vec.x >= min.x &&
			        vec.y <= max.y && vec.y >= min.y);
		}
		else
		{
			return (vec.x < max.x && vec.x > min.x &&
			        vec.y < max.y && vec.y > min.y);
		}
	}
	
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector3 vec, Vector3 threshold, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= threshold.x && vec.x >= -threshold.x &&
			        vec.y <= threshold.y && vec.y >= -threshold.y &&
			        vec.z <= threshold.z && vec.z >= -threshold.z);
		}
		else
		{
			return (vec.x < threshold.x && vec.x > -threshold.x &&
			        vec.y < threshold.y && vec.y > -threshold.y &&
			        vec.z < threshold.z && vec.z > -threshold.z);
		}
	}
	
	/// <summary>
	/// checks if all components of the vector are in a given range
	/// </summary>
	public static bool ComponentsInRange(this Vector2 vec, Vector3 threshold, bool includeBorder = true)
	{
		if (includeBorder)
		{
			return (vec.x <= threshold.x && vec.x >= -threshold.x &&
			        vec.y <= threshold.y && vec.y >= -threshold.y);
		}
		else
		{
			return (vec.x < threshold.x && vec.x > -threshold.x &&
			        vec.y < threshold.y && vec.y > -threshold.y);
		}
	}
}