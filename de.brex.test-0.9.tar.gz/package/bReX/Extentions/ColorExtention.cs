/*
 * @author:		CT
 * @date:		22/05/2017 09:38
 * @project:	Essentials
 * @company:	b.ReX
 */

using UnityEngine;

/// <summary>
/// ColorExtention
/// some extentions for the color component
/// </summary>
public static class ColorExtention
{
	/// <summary>
	/// function to get hex string from color
	/// </summary>
	/// <param name="color">this color</param>
	/// <returns></returns>
	public static string ColorToHex(this Color color)
    {
        Color32 c = color;
        string hex = c.r.ToString("X2") + c.g.ToString("X2") + c.b.ToString("X2");
        return hex;
    }
	
	/// <summary>
	/// function to get color from hex string
	/// </summary>
	/// <param name="color">this color</param>
	/// <param name="_hex">string from witch the color is extracted</param>
	/// <returns></returns>
	public static Color HexToColor(this Color color, string _hex)
    {
        byte r = byte.Parse(_hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
        byte g = byte.Parse(_hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
        byte b = byte.Parse(_hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);
        return new Color32(r, g, b, 255);
    }
	
	/// <summary>
	/// function to get half of the color (intensity)
	/// </summary>
	/// <param name="color">this color</param>
	/// <returns></returns>
	public static Color HalfColor (this Color color)
    {
        return ColorIntensity(color, .5f);
    }
	
	/// <summary>
	/// function to get a arbetrary alount of the color (intensity)
	/// </summary>
	/// <param name="color">this color</param>
	/// <param name="_val">intensity multiplicator</param>
	/// <returns></returns>
	public static Color ColorIntensity(this Color color, float _val)
    {
      return color * new Vector4(_val, _val, _val, 1);
    }

}