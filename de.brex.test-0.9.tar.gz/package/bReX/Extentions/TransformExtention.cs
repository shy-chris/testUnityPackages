/*
 * @author:		CT
 * @date:		22/05/2017 09:38
 * @project:	Essentials
 * @company:	b.ReX
 */

using UnityEngine;

/// <summary>
/// TransformExtention
/// some extentions for the transform component
/// </summary>
public static class TransformExtention
{
	/// <summary>
	/// function resets LOCAL rotation, position and scale
	/// </summary>
	/// <param name="trans">this transform</param>
	public static void ResetLocalTransformation(this Transform trans)
	{
		trans.SetLocalTransformation(Vector3.zero, Quaternion.identity, Vector3.one);
	}
	
	/// <summary>
	/// function sets LOCAL position, rotation and scale to the three input values (with vector for eulerangle) 
	/// </summary>
	/// <param name="trans">this transform</param>
	/// <param name="position">set to this position vector</param>
	/// <param name="rotation">set to this rotation vector</param>
	/// <param name="scale">set to this scale vector</param>
	public static void SetLocalTransformation(this Transform trans, Vector3 position, Vector3 rotation, Vector3 scale)
	{
		trans.SetLocalTransformation(position, Quaternion.Euler(rotation), scale);
	}
	
	/// <summary>
	/// function sets LOCAL position, rotation and scale to the three input values (with quaternion for rotation)
	/// </summary>
	/// <param name="trans"> this transform</param>
	/// <param name="position">set to this position vector</param>
	/// <param name="rotation">set to this rotation quaternion</param>
	/// <param name="scale">set to this scale verctor</param>
	public static void SetLocalTransformation(this Transform trans, Vector3 position, Quaternion rotation, Vector3 scale)
	{
		trans.localPosition = position;
		trans.localRotation = rotation;
		trans.localScale = scale;
	}
	
	/// <summary>
	/// function resets GLOBAL rotation, position and scale
	/// </summary>
	/// <param name="trans">this transform</param>
	public static void ResetGlobalTransformation(this Transform trans)
	{
		trans.SetGlobalTransformation(Vector3.zero, Quaternion.identity, Vector3.one);
	}
	
	/// <summary>
	/// function sets GLOBAL position, rotation and scale to the three input values (with vector for eulerangle) 
	/// </summary>
	/// <param name="trans">this transform</param>
	/// <param name="position">set to this position vector</param>
	/// <param name="rotation">set to this rotation vector</param>
	/// <param name="scale">set to this scale vector</param>
	public static void SetGlobalTransformation(this Transform trans, Vector3 position, Vector3 rotation, Vector3 scale)
	{
		trans.SetGlobalTransformation(position, Quaternion.Euler(rotation), scale);
	}

	/// <summary>
	/// sets GLOBAL position, rotation and scale to the three input values (with vector for eulerangle) 
	/// </summary>
	/// <param name="trans">this transform</param>
	/// <param name="position">set to this position vector</param>
	/// <param name="rotation">set to this rotation vector</param>
	/// <param name="scale">set to this scale vector</param>
	public static void SetGlobalTransformation(this Transform trans, Vector3 position, Quaternion rotation, Vector3 scale)
	{
		trans.position = position;
		trans.rotation = rotation;
		trans.localScale = scale;
	}
	
	/// <summary>
	/// trys to get the first component from Sibling Gameobjects
	/// </summary>
	/// <param name="trans">this transform</param>
	/// <typeparam name="T">the component to search for</typeparam>
	/// <returns></returns>
	public static T GetComponentInSiblings<T>(this Transform trans)
	{
		return trans.parent.GetComponentInChildren<T>();
	}
	
	/// <summary>
	/// trys to get all components from Sibling Gameobjects
	/// </summary>
	/// <param name="trans">this transform</param>
	/// <typeparam name="T">the component to search for</typeparam>
	/// <returns></returns>
	public static T[] GetComponentsInSiblings<T>(this Transform trans)
	{
		return trans.parent.GetComponentsInChildren<T>();
	}
	
	/// <summary>
	/// trys to get the first component from Sibling Gameobjects
	/// </summary>
	/// <param name="trans">this transform</param>
	/// <param name="type">the component to search for</param>
	/// <returns></returns>
	public static Component GetComponentInSibling(this Transform trans, System.Type type)
	{
		return trans.parent.GetComponentInChildren(type);
	}
	
	/// <summary>
	/// trys to get all components from Sibling Gameobjects
	/// </summary>
	/// <param name="trans">this transform</param>
	/// <param name="type">the component to search for</param>
	/// <returns></returns>
	public static Component[] GetComponentsInSibling(this Transform trans, System.Type type)
	{
		return trans.parent.GetComponentsInChildren(type);
	}
}
