/*
 * @author:		CT
 * @date:		22/05/2017 09:38
 * @project:	Essentials
 * @company:	b.ReX
 */

using UnityEngine;

/// <summary>
/// CanvasGroupExtention
/// some extentions for the canvasgroup component
/// </summary>
public static class CanvasGroupExtention
{
	/// <summary>
	/// function activate canvasgroup - interactable and blockraycast = true and alpha = 1
	/// </summary>
	/// <param name="cg">this canvas group</param>
	public static void Activate(this CanvasGroup cg)
	{
		cg.interactable = cg.blocksRaycasts = true;
		cg.alpha = 1.0f;
	}
	
	/// <summary>
	/// function deactivate canvasgroup - interactable and blockraycast = false and alpha = 0
	/// </summary>
	/// <param name="cg">this canvas group</param>
	public static void Deactivate(this CanvasGroup cg)
	{
		cg.interactable = cg.blocksRaycasts = false;
		cg.alpha = 0.0f;
	}
	
	/// <summary>
	/// function toggles activity of canvasgroup
	/// </summary>
	/// <param name="cg">this canvas group</param>
	public static void ToggleActivity(this CanvasGroup cg)
	{
		if(cg.interactable == true && cg.blocksRaycasts == true && cg.alpha >= 0.99f)
			cg.Activate();
		else if(cg.interactable == false && cg.blocksRaycasts == false && cg.alpha <= 0.01f)
			cg.Deactivate();
	}
}
