/*
 * @author:		CT
 * @date:		22/05/2017 09:38
 * @project:	Essentials
 * @company:	b.ReX
 */

using UnityEngine;

/// <summary>
/// GameobjectExtention
/// some extentions for the gameobject component
/// </summary>
public static class GameobjectExtention
{
	/// <summary>
	/// triggers the setActive of the gameobject
	/// </summary>
	/// <param name="go">this gameobject</param>
	public static void TriggerActive(this GameObject go)
	{
		go.SetActive(!go.activeSelf);
	}
}
