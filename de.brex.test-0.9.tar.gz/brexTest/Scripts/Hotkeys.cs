using UnityEditor;

public class Hotkeys 
{
	[MenuItem("Hotkeys/OpenInputSettings _F5")]
	static void OpenInputSettings()
	{
		EditorApplication.ExecuteMenuItem("Edit/Project Settings/Input");
	}
	
	[MenuItem("Hotkeys/OpenPlayerSettings _F6")]
	static void OpenPlayerSettings()
	{
		EditorApplication.ExecuteMenuItem("Edit/Project Settings/Player");
	}
}